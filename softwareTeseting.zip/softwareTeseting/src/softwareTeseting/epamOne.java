package softwareTeseting;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class epamOne {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver");
	//	driver.get("https://accounts.google.com");
		driver.get("https://www.flipkart.com/");
		//System.out.println(driver.getTitle());
		//driver.close();
		driver.findElement(By.className("_1_3w1N")).click();
		driver.findElement(By.className("_2IX_2- VJZDxU")).sendKeys("6302717251");
		driver.findElement(By.className("_2KpZ6l _2HKlqd _3AWRsL")).click();
		String m=sc.next();
		driver.findElement(By.id("_2IX_2- _1WRfas")).sendKeys(m);
		driver.findElement(By.className("_2KpZ6l _14EHzR _3dESVI")).click();
	}

}
